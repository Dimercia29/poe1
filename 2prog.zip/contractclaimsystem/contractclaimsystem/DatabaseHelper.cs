﻿using System;
using System.Data.SqlClient;
using System.Windows;

public class DatabaseHelper
{
    private string connectionString = "Server=labG9AEB3\\SQLEXPRESS;Database=CMCS_DB;Trusted_Connection=True;";

    public void TestConnection()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                connection.Open();
                MessageBox.Show("Connection successful!");
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"General Error: {ex.Message}");
            }
        }
    

}
}
