﻿using System;
using System.Security.Claims;
using System.Windows;

namespace CMCS
{
    public partial class LecturerClaimForm : Window
    {
        public LecturerClaimForm()
        {
            InitializeComponent();
        }

        // Submit claim button click event
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Validate inputs
                if (string.IsNullOrEmpty(txtHoursWorked.Text) || string.IsNullOrEmpty(txtHourlyRate.Text))
                {
                    MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Create a Claim object (assuming you have a Claim class)
                var claim = new Claim
                {
                    HoursWorked = decimal.Parse(txtHoursWorked.Text),
                    HourlyRate = decimal.Parse(txtHourlyRate.Text),
                    Notes = txtNotes.Text,
                    ClaimStatus = "Pending" // Default status
                };

                // Submit claim to database (via ClaimService)
                ClaimService.SubmitClaim(claim);
                MessageBox.Show("Claim submitted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                // Clear form fields after submission
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Submission Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearForm()
        {
            txtHoursWorked.Text = "";
            txtHourlyRate.Text = "";
            txtNotes.Text = "";
        }
    }
}
