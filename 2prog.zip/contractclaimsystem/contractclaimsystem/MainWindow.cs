﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            HideActionButtons();
            // Register the Window_Loaded event
            this.Loaded += Window_Loaded;
        }

        // Role Selection - Show/Hide buttons based on the selected role
        private void RoleButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;

            if (button == LecturerButton)
            {
                SubmitClaimButton.Visibility = Visibility.Visible;
                UploadDocumentsButton.Visibility = Visibility.Visible;
                VerifyClaimsButton.Visibility = Visibility.Collapsed;
            }
            else if (button == CoordinatorButton || button == AcademicManagerButton)
            {
                SubmitClaimButton.Visibility = Visibility.Collapsed;
                UploadDocumentsButton.Visibility = Visibility.Collapsed;
                VerifyClaimsButton.Visibility = Visibility.Visible;
            }
        }

        // Hide all action buttons initially
        private void HideActionButtons()
        {
            SubmitClaimButton.Visibility = Visibility.Collapsed;
            UploadDocumentsButton.Visibility = Visibility.Collapsed;
            VerifyClaimsButton.Visibility = Visibility.Collapsed;
        }

        // Lecturer: Submit Claim functionality
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            LecturerClaimForm claimForm = new LecturerClaimForm();
            claimForm.Show();
        }

        // Lecturer: Upload Documents functionality
        private void UploadDocuments_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Upload documents functionality not implemented yet.");
        }

        // Coordinator/Manager: Verify Claims functionality
        private void VerifyClaims_Click(object sender, RoutedEventArgs e)
        {
            ClaimApprovalView claimApprovalView = new ClaimApprovalView();
            claimApprovalView.Show();
        }

        // Handle the Window Loaded event to test database connection
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DatabaseHelper dbHelper = new DatabaseHelper();
            dbHelper.TestConnection();
        }
    }
}
