﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;

namespace CMCS
{
    public partial class UploadDocumentsWindow : Window
    {
        private string _selectedFilePath = string.Empty;  // Store the selected file path

        public UploadDocumentsWindow(int claimID)
        {
            InitializeComponent();
            ClaimIDTextBox.Text = claimID.ToString();  // Set the claim ID (passed in as a parameter)
        }

        // Event handler for the "Browse" button click
        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf|Word files (*.docx)|*.docx|Excel files (*.xlsx)|*.xlsx";  // Restrict file types

            if (openFileDialog.ShowDialog() == true)
            {
                _selectedFilePath = openFileDialog.FileName;  // Store the selected file path
                SelectedFileTextBlock.Text = Path.GetFileName(_selectedFilePath);  // Show the selected file name
            }
        }

        // Event handler for the "Upload Document" button click
        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_selectedFilePath))
            {
                MessageBox.Show("Please select a file before uploading.", "No File Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Define where the uploaded file will be saved (you may want to adjust this path)
                string destinationFolder = @"C:\UploadedDocuments\";  // Ensure the folder exists or create it
                string destinationPath = Path.Combine(destinationFolder, Path.GetFileName(_selectedFilePath));

                // Copy the file to the destination folder
                File.Copy(_selectedFilePath, destinationPath, true);

                // Update the claim record in the database with the file path
                int claimID = int.Parse(ClaimIDTextBox.Text);
                ClaimService.UpdateClaimWithDocument(claimID, destinationPath);

                // Provide success feedback
                StatusTextBlock.Text = "Status: Document uploaded successfully!";
                StatusTextBlock.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Green);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error uploading document: {ex.Message}", "Upload Error", MessageBoxButton.OK, MessageBoxImage.Error);
                StatusTextBlock.Text = "Status: Upload failed.";
                StatusTextBlock.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Red);
            }
        }
    }
}

