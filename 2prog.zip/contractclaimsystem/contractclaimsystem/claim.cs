﻿namespace CMCS.Models  // Change this if your namespace is different
{
    public class Claim
    {
        public int ClaimID { get; set; }
        public int LecturerID { get; set; }   // ID of the lecturer submitting the claim
        public string LecturerName { get; set; }  // Name of the lecturer
        public DateTime DateSubmitted { get; set; }  // When the claim was submitted
        public string Description { get; set; }  // Description of the claim
        public string Status { get; set; }  // Pending, Approved, Rejected
        public decimal HoursWorked { get; set; }  // Number of hours worked
        public decimal HourlyRate { get; set; }  // Hourly rate for the work
        public string Notes { get; set; }  // Any additional notes
        public string ClaimStatus { get; set; }  // Status of the claim (Pending, Approved, etc.)
        public string DocumentPath { get; set; }  // Path to any uploaded supporting document
    }
}
