﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using CMCS.Models;  // Reference to the Claim model

namespace CMCS.Services  // Change this if your namespace is different
{
    public static class ClaimService
    {
        // Change this connection string to match your database settings
        private static string connectionString = "your-connection-string-here";

        // Method to submit a claim to the database
        public static void SubmitClaim(Claim claim)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"INSERT INTO Claims 
                                (LecturerID, LecturerName, DateSubmitted, Status, HoursWorked, HourlyRate, Notes, DocumentPath) 
                                VALUES (@LecturerID, @LecturerName, @DateSubmitted, @Status, @HoursWorked, @HourlyRate, @Notes, @DocumentPath)";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@LecturerID", claim.LecturerID);
                cmd.Parameters.AddWithValue("@LecturerName", claim.LecturerName);
                cmd.Parameters.AddWithValue("@DateSubmitted", claim.DateSubmitted);
                cmd.Parameters.AddWithValue("@Status", claim.Status);
                cmd.Parameters.AddWithValue("@HoursWorked", claim.HoursWorked);
                cmd.Parameters.AddWithValue("@HourlyRate", claim.HourlyRate);
                cmd.Parameters.AddWithValue("@Notes", claim.Notes);
                cmd.Parameters.AddWithValue("@DocumentPath", claim.DocumentPath);

                cmd.ExecuteNonQuery();
            }
        }

        // Method to retrieve pending claims
        public static List<Claim> GetPendingClaims()
        {
            List<Claim> claims = new List<Claim>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Claims WHERE Status = 'Pending'";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Claim claim = new Claim
                    {
                        ClaimID = reader.GetInt32(0),
                        LecturerID = reader.GetInt32(1),
                        LecturerName = reader.GetString(2),
                        DateSubmitted = reader.GetDateTime(3),
                        Status = reader.GetString(4),
                        HoursWorked = reader.GetDecimal(5),
                        HourlyRate = reader.GetDecimal(6),
                        Notes = reader.GetString(7),
                        DocumentPath = reader.GetString(8)
                    };
                    claims.Add(claim);
                }
            }

            return claims;
        }

        // Method to update a claim's document path in the database
        public static void UpdateClaimWithDocument(int claimID, string documentPath)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Claims SET DocumentPath = @DocumentPath WHERE ClaimID = @ClaimID";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@DocumentPath", documentPath);
                cmd.Parameters.AddWithValue("@ClaimID", claimID);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
