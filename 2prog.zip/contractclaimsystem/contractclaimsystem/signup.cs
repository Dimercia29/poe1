﻿using System;
using System.Security.Claims;
using System.Windows;


namespace CMCS
{
    public partial class SubmitClaimWindow : Window
    {
        public SubmitClaimWindow()
        {
            InitializeComponent();
            InitializeForm();
        }

        // Initialize form with default values like submission date
        private void InitializeForm()
        {
            SubmissionDateTextBox.Text = DateTime.Now.ToShortDateString();  // Set current date
            ClaimIDTextBox.Text = "Auto-generated";  // Placeholder for auto-generated ID
        }

        // Event handler for the "Submit Claim" button click
        private void SubmitClaimButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate the input fields
            if (string.IsNullOrEmpty(LecturerIDTextBox.Text) || string.IsNullOrEmpty(ClaimDescriptionTextBox.Text))
            {
                MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                // Create a new Claim object
                Claim newClaim = new Claim
                {
                    LecturerID = int.Parse(LecturerIDTextBox.Text),
                    Description = ClaimDescriptionTextBox.Text,
                    SubmissionDate = DateTime.Now,
                    Status = "Pending"  // Initial status is Pending
                };

                // Submit the claim using the ClaimService
                ClaimService.SubmitClaim(newClaim);

                // Provide feedback to the user
                FeedbackTextBlock.Text = "Claim submitted successfully!";
                FeedbackTextBlock.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Green);

                // Clear the form after submission
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting claim: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                FeedbackTextBlock.Text = "Failed to submit claim.";
                FeedbackTextBlock.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Red);
            }
        }

        // Method to clear the form after submission
        private void ClearForm()
        {
            LecturerIDTextBox.Text = string.Empty;
            ClaimDescriptionTextBox.Text = string.Empty;
            SubmissionDateTextBox.Text = DateTime.Now.ToShortDateString();  // Reset the date
        }
    }
}
