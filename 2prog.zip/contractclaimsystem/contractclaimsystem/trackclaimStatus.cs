﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Windows;


namespace CMCS
{
    public partial class TrackClaimStatusWindow : Window
    {
        public TrackClaimStatusWindow()
        {
            InitializeComponent();
            LoadClaims();
        }

        // Method to load the claims into the ListView
        private void LoadClaims()
        {
            try
            {
                // Get all claims from the database (ClaimService should handle this)
                List<Claim> claims = ClaimService.GetAllClaims();

                // Bind the claim list to the ListView
                ClaimListView.ItemsSource = claims;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading claims: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // When a user selects a claim, show its details
        private void ClaimListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ClaimListView.SelectedItem is Claim selectedClaim)
            {
                // Populate the Claim Details section
                LecturerTextBlock.Text = $"Lecturer: {selectedClaim.LecturerName}";
                DateTextBlock.Text = $"Date Submitted: {selectedClaim.DateSubmitted.ToShortDateString()}";
                DescriptionTextBlock.Text = $"Description: {selectedClaim.Description}";
                StatusHistoryTextBlock.Text = $"Status: {selectedClaim.Status}";
            }
        }
    }
}
}
